/*
 * @作者: kerwin
 */
import React from 'react'
import { Card, Col, Button, Row, Table } from 'antd';
import {useSelector} from 'react-redux'
import moment from 'moment'

function converTime(t){
    return moment(t*1000).format("YYYY/MM/DD")
}

function convert(n) {
    //window.web
    if (!window.web || !n) return
    return window.web.web3.utils.fromWei(n, "ether");
}

function getRenderOrder(order,type){
    if(!window.web) return []

    const account = window.web.account
    // 1. Exclude completed and cancelled orders
    let filterIds = [...order.CancelOrders,...order.FillOrders].map(item=>item.id)
    // console.log(filterIds)
    let pendingOrders = order.AllOrders.filter(item=> !filterIds.includes(item.id))
    // console.log(pendingOrders)
    if(type===1){
        return pendingOrders.filter(item=>item.user===account)
    }else{
        return pendingOrders.filter(item=>item.user!==account)
    }
}


export default function Order() {
    const order = useSelector(state => state.order)
    console.log(order)

    const columns = [
        {
            title: 'Time',
            dataIndex: 'timestamp',
            render:(timestamp)=><div>{converTime(timestamp)}</div>
        },
        {
            title: 'KWT',
            dataIndex: 'amountGet',
            render:(amountGet)=><b>{convert(amountGet)}</b>
        },
        {
            title: 'ETH',
            dataIndex: 'amountGive',
            render:(amountGive)=><b>{convert(amountGive)}</b>
        },
    ];

    const columns1 = [
        ...columns,
        {
            title: 'Action',
            render:(item)=><Button type="primary" onClick = {()=>{
                const {exchange,account} = window.web
                exchange.methods
                .cancelOrder(item.id)
                .send({ from: account })
            }}>Cancel</Button>
        },
    ];
    const columns2 = [
        ...columns,
        {
            title: 'Action',
            render:(item)=><Button danger onClick = {async ()=>{
                if (!window.web || !window.web.exchange || !window.web.account) {
                    alert('Please connect your wallet first');
                    return;
                }
                
                try {
                    const {exchange, account, web3, token} = window.web;
                    const ETHER_ADDRESS = '0x0000000000000000000000000000000000000000';

                    // 1. 检查当前连接的账户
                    console.log('Current account:', account);

                    // 2. 检查交易所中的余额
                    const ethInExchange = await exchange.methods.balanceOf(ETHER_ADDRESS, account).call();
                    console.log('ETH in exchange:', web3.utils.fromWei(ethInExchange));

                    // 检查 KWT 余额
                    const kwtInExchange = await exchange.methods.balanceOf(token._address, account).call();
                    console.log('KWT in exchange:', web3.utils.fromWei(kwtInExchange));

                    // 3. 检查钱包余额
                    const ethInWallet = await web3.eth.getBalance(account);
                    console.log('ETH in wallet:', web3.utils.fromWei(ethInWallet));

                    // 4. 检查是否有足够的 ETH 在交易所
                    if (web3.utils.toBN(ethInExchange).lt(web3.utils.toBN(item.amountGive))) {
                        const required = web3.utils.fromWei(item.amountGive);
                        const available = web3.utils.fromWei(ethInExchange);
                        alert(`You need ${required} ETH in exchange but only have ${available} ETH. Please deposit more ETH first.`);
                        return;
                    }

                    // 5. 检查订单状态
                    const orderFilled = await exchange.methods.orderFill(item.id).call();
                    const orderCancelled = await exchange.methods.orderCancel(item.id).call();
                    
                    console.log('=== Order Status ===');
                    console.log('Order Filled:', orderFilled);
                    console.log('Order Cancelled:', orderCancelled);

                    if (orderFilled || orderCancelled) {
                        alert('This order is no longer available');
                        return;
                    }

                    // 6. 执行交易
                    console.log('=== Executing Transaction ===');
                    const result = await exchange.methods
                        .fillOrder(item.id)
                        .send({ 
                            from: account,
                            gas: 300000
                        });

                    console.log('Transaction successful:', result);
                    alert('Order filled successfully!');
                    
                } catch (error) {
                    console.error('=== Transaction Error ===');
                    console.error('Error details:', error);
                    
                    let errorMessage = 'Purchase failed: ';
                    if (error.data && error.data.reason) {
                        if (error.data.reason.includes('余额不足')) {
                            errorMessage += 'Insufficient ETH balance in exchange. Please deposit ETH first.';
                        } else {
                            errorMessage += error.data.reason;
                        }
                    } else if (error.message.includes('insufficient funds')) {
                        errorMessage += 'Insufficient ETH for gas fees';
                    } else if (error.message.includes('User denied')) {
                        errorMessage += 'Transaction was rejected';
                    } else {
                        errorMessage += error.message;
                    }
                    
                    alert(errorMessage);
                }
            }}>Buy</Button>
        },
    ];

    return (
        <div style={{ marginTop: "10px" }}>
            <Row >
                <Col span={8}>
                    <Card title="Completed Trades" bordered={false} style={{ margin: 10 }}>
                        <Table dataSource={order.FillOrders} columns={columns} rowKey={item=>item.id}/>
                    </Card>
                </Col>
                <Col span={8}>
                    <Card title="My Orders" bordered={false} style={{
                        margin: 10
                    }}>
                        <Table dataSource={getRenderOrder(order,1)} columns={columns1} rowKey={item=>item.id}/>
                    </Card>
                </Col>
                <Col span={8}>
                    <Card title="Other Orders" bordered={false} style={{
                        margin: 10
                    }}>
                        <Table dataSource={getRenderOrder(order,2)} columns={columns2} rowKey={item=>item.id}/>
                    </Card>
                </Col>
            </Row>
        </div>
    )
}
