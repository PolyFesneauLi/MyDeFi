import React, { useState } from 'react';
import { Card, Tabs, Form, Input, Button, message } from 'antd';

export default function DepositWithdraw() {
    const [loading, setLoading] = useState(false);
    const [activeTab, setActiveTab] = useState('deposit');

    const onDeposit = async (values) => {
        if (!window.web) {
            message.error('Please connect your wallet first');
            return;
        }

        setLoading(true);
        try {
            const { exchange, account, token } = window.web;
            const amount = window.web.web3.utils.toWei(values.amount, 'ether');

            if (activeTab === 'deposit') {
                // Deposit ETH
                await exchange.methods
                    .depositEther()
                    .send({ from: account, value: amount });
                message.success('ETH deposited successfully!');
            } else {
                // Deposit KWT
                await token.methods
                    .approve(exchange._address, amount)
                    .send({ from: account });
                await exchange.methods
                    .depositToken(token._address, amount)
                    .send({ from: account });
                message.success('KWT deposited successfully!');
            }
        } catch (error) {
            console.error('Deposit error details:', error);
            message.error('Deposit failed: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const onWithdraw = async (values) => {
        if (!window.web) {
            message.error('Please connect your wallet first');
            return;
        }

        setLoading(true);
        try {
            const { exchange, account, token } = window.web;
            const amount = window.web.web3.utils.toWei(values.amount, 'ether');

            if (activeTab === 'deposit') {
                // Withdraw ETH
                await exchange.methods
                    .withdrawEther(amount)
                    .send({ from: account });
                message.success('ETH withdrawn successfully!');
            } else {
                // Withdraw KWT
                const exchangeBalance = await exchange.methods
                    .balanceOf(token._address, account)
                    .call();
                console.log('KWT balance in exchange:', window.web.web3.utils.fromWei(exchangeBalance));

                if (window.web.web3.utils.toBN(exchangeBalance).lt(window.web.web3.utils.toBN(amount))) {
                    throw new Error('Insufficient KWT balance in exchange');
                }

                await exchange.methods
                    .withdrawToken(token._address, amount)
                    .send({ from: account });
                message.success('KWT withdrawn successfully!');
            }
        } catch (error) {
            console.error('Withdrawal error details:', error);
            message.error('Withdrawal failed: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card title="Deposit & Withdraw" style={{ marginTop: 16 }}>
            <Tabs
                activeKey={activeTab}
                onChange={setActiveTab}
                items={[
                    {
                        key: 'deposit',
                        label: 'ETH Operations',
                    },
                    {
                        key: 'withdraw',
                        label: 'KWT Operations',
                    },
                ]}
            />
            <div style={{ marginTop: 16 }}>
                <Form onFinish={onDeposit}>
                    <Form.Item
                        label="Deposit Amount"
                        name="amount"
                        rules={[{ required: true, message: 'Please enter amount' }]}
                    >
                        <Input placeholder="Enter amount" />
                    </Form.Item>
                    <Form.Item>
                        <Button type="primary" htmlType="submit" loading={loading} block>
                            Deposit
                        </Button>
                    </Form.Item>
                </Form>
                <Form onFinish={onWithdraw} style={{ marginTop: 16 }}>
                    <Form.Item
                        label="Withdraw Amount"
                        name="amount"
                        rules={[{ required: true, message: 'Please enter amount' }]}
                    >
                        <Input placeholder="Enter amount" />
                    </Form.Item>
                    <Form.Item>
                        <Button danger htmlType="submit" loading={loading} block>
                            Withdraw
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </Card>
    );
} 