/*
 * @作者: kerwin
 */
import {useEffect} from 'react'
import {useDispatch} from 'react-redux'
import Web3 from 'web3'
import tokenjson from '../build/KerwinToken.json'
import exchangejson from '../build/Exchange.json'
import Balance from './Balance'
import Order from './Order'
import CreateOrder from './CreateOrder'
import DepositWithdraw from './DepositWithdraw'
import { loadBalanceData } from '../redux/slices/balanceSlice'
import { loadCancelOrderData,loadAllOrderData,loadFillOrderData } from '../redux/slices/orderSlice'
import { Layout, message } from 'antd'

const { Header, Content: AntContent } = Layout;

export default function ExchangeContent() {
    const dispatch = useDispatch()
    useEffect( () => {
        async function  start(){
            try {
                //1. Get connected contracts
                const web = await initWeb()
                console.log(web)
                window.web = web //global object

                //2. Get balance information
                dispatch(loadBalanceData(web))
                //3. Get order information
                dispatch(loadCancelOrderData(web))
                dispatch(loadAllOrderData(web))
                dispatch(loadFillOrderData(web))

                //Listen to events
                web.exchange.events.Order({},(error,event)=>{
                    dispatch(loadAllOrderData(web))
                })
                web.exchange.events.Cancel({},(error,event)=>{
                    dispatch(loadCancelOrderData(web))
                })
                web.exchange.events.Trade({},(error,event)=>{
                    dispatch(loadFillOrderData(web))
                    dispatch(loadBalanceData(web))
                })
            } catch (error) {
                message.error('Connection failed: ' + error.message);
            }
        }
        start()
    }, [dispatch])

    async function initWeb(){
        var web3 = new Web3(Web3.givenProvider || "http://localhost:7545");
     
        //Request authorization
        let accounts = await web3.eth.requestAccounts()
        console.log(accounts[0])

        //Get networkId
        const networkId = await web3.eth.net.getId();

        const tokenabi = tokenjson.abi
        const tokenaddress = tokenjson.networks[networkId].address
        const token = await new web3.eth.Contract(tokenabi,tokenaddress);

        const exchangeabi = exchangejson.abi
        const exchangeaddress = exchangejson.networks[networkId].address
        const exchange = await new web3.eth.Contract(exchangeabi,exchangeaddress);

        return {
            web3,
            account:accounts[0],
            token,
            exchange
        }
    }

    return (
        <Layout style={{ minHeight: '100vh' }}>
            <Header style={{ background: '#fff', padding: 0, textAlign: 'center' }}>
                <h1>KWT Exchange</h1>
            </Header>
            <AntContent style={{ padding: '24px' }}>
                <Balance />
                <DepositWithdraw />
                <CreateOrder />
                <Order />
            </AntContent>
        </Layout>
    )
}
