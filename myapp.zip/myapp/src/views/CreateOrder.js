import React, { useState } from 'react';
import { Card, Form, Input, Button, message } from 'antd';

export default function CreateOrder() {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);

    const onFinish = async (values) => {
        if (!window.web) {
            message.error('Please connect your wallet first');
            return;
        }

        setLoading(true);
        try {
            const { exchange, account, token, web3 } = window.web;
            const amountGet = web3.utils.toWei(values.amountGet, 'ether');
            const amountGive = web3.utils.toWei(values.amountGive, 'ether');

            // Get token addresses
            const ETHER = '0x0000000000000000000000000000000000000000';
            const tokenAddress = token._address;

            console.log('Creating order with parameters:');
            console.log('tokenAddress:', tokenAddress);
            console.log('amountGet:', amountGet);
            console.log('ETHER:', ETHER);
            console.log('amountGive:', amountGive);
            console.log('account:', account);

            // Check token balance first
            const tokenBalance = await token.methods.balanceOf(account).call();
            console.log('Token balance:', tokenBalance);

            // Check exchange balance
            const exchangeBalance = await exchange.methods.balanceOf(tokenAddress, account).call();
            console.log('Exchange balance:', exchangeBalance);

            // Check if we need to approve first
            const allowance = await token.methods.allowance(account, exchange._address).call();
            console.log('Current allowance:', allowance);

            // Check if we need to deposit ETH
            const ethBalance = await exchange.methods.balanceOf(ETHER, account).call();
            console.log('ETH balance in exchange:', ethBalance);

            if (ethBalance < amountGive) {
                console.log('Depositing ETH...');
                const ethToDeposit = web3.utils.toBN(amountGive).sub(web3.utils.toBN(ethBalance));
                await exchange.methods.depositEther()
                    .send({ from: account, value: ethToDeposit.toString() });
                console.log('ETH deposit successful');
            }

            if (allowance < amountGet) {
                console.log('Approving tokens...');
                await token.methods.approve(exchange._address, amountGet)
                    .send({ from: account });
                console.log('Approval successful');
            }

            const tokenBalanceInExchange = await exchange.methods.balanceOf(tokenAddress, account).call();
            if (tokenBalanceInExchange < amountGet) {
                console.log('Depositing tokens...');
                const tokensToDeposit = web3.utils.toBN(amountGet).sub(web3.utils.toBN(tokenBalanceInExchange));
                await exchange.methods.depositToken(tokenAddress, tokensToDeposit.toString())
                    .send({ from: account });
                console.log('Token deposit successful');
            }

            const order = await exchange.methods.makeOrder(
                tokenAddress,  // tokenGet (KWT)
                amountGet,     // amountGet
                ETHER,         // tokenGive (ETH)
                amountGive     // amountGive
            ).send({ from: account });

            console.log('Order created:', order);
            message.success('Order created successfully!');
            form.resetFields();
        } catch (error) {
            console.error('Error creating order:', error);
            message.error('Failed to create order: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card title="Create New Order" style={{ marginTop: 16 }}>
            <Form
                form={form}
                layout="vertical"
                onFinish={onFinish}
            >
                <Form.Item
                    label="Amount of KWT to Get"
                    name="amountGet"
                    rules={[{ required: true, message: 'Please enter amount' }]}
                >
                    <Input placeholder="Enter amount" />
                </Form.Item>
                <Form.Item
                    label="Amount of ETH to Give"
                    name="amountGive"
                    rules={[{ required: true, message: 'Please enter amount' }]}
                >
                    <Input placeholder="Enter amount" />
                </Form.Item>
                <Form.Item>
                    <Button type="primary" htmlType="submit" loading={loading} block>
                        Create Order
                    </Button>
                </Form.Item>
            </Form>
        </Card>
    );
} 