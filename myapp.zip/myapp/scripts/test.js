/*
 * @作者: kerwin
 */
const Web3 = require('web3');
const tokenjson = require('../build/KerwinToken.json');
const exchangejson = require('../build/Exchange.json');

async function testExchange() {
    // 连接到本地开发网络
    const web3 = new Web3('http://localhost:8545');
    
    // 获取账户
    const accounts = await web3.eth.getAccounts();
    const account1 = accounts[0];
    const account2 = accounts[1];
    
    // 获取网络ID
    const networkId = await web3.eth.net.getId();
    
    // 获取合约实例
    const tokenAddress = tokenjson.networks[networkId].address;
    const exchangeAddress = exchangejson.networks[networkId].address;
    
    const token = new web3.eth.Contract(tokenjson.abi, tokenAddress);
    const exchange = new web3.eth.Contract(exchangejson.abi, exchangeAddress);
    
    console.log('Starting exchange tests...');
    
    try {
        // 1. 测试代币转账
        console.log('Testing token transfer...');
        await token.methods.transfer(account2, web3.utils.toWei('1000', 'ether'))
            .send({ from: account1 });
        console.log('Token transfer successful');
        
        // 2. 测试存款
        console.log('Testing ETH deposit...');
        await exchange.methods.depositEther()
            .send({ from: account1, value: web3.utils.toWei('1', 'ether') });
        console.log('ETH deposit successful');
        
        // 3. 测试代币存款
        console.log('Testing token deposit...');
        await token.methods.approve(exchangeAddress, web3.utils.toWei('100', 'ether'))
            .send({ from: account1 });
        await exchange.methods.depositToken(tokenAddress, web3.utils.toWei('100', 'ether'))
            .send({ from: account1 });
        console.log('Token deposit successful');
        
        // 4. 测试创建订单
        console.log('Testing order creation...');
        const ETHER = '0x0000000000000000000000000000000000000000';
        await exchange.methods.makeOrder(
            tokenAddress,
            web3.utils.toWei('10', 'ether'),
            ETHER,
            web3.utils.toWei('0.1', 'ether')
        ).send({ from: account1 });
        console.log('Order creation successful');
        
        // 5. 测试填充订单
        console.log('Testing order filling...');
        await exchange.methods.fillOrder(1)
            .send({ from: account2 });
        console.log('Order filling successful');
        
        // 6. 测试提现
        console.log('Testing withdrawals...');
        await exchange.methods.withdrawEther(web3.utils.toWei('0.5', 'ether'))
            .send({ from: account1 });
        await exchange.methods.withdrawToken(tokenAddress, web3.utils.toWei('50', 'ether'))
            .send({ from: account1 });
        console.log('Withdrawals successful');
        
        console.log('All tests completed successfully!');
        
    } catch (error) {
        console.error('Test failed:', error);
    }
}

testExchange();

