const KerwinToken = artifacts.require("KerwinToken.sol");

// 辅助函数：将数字转换为 wei 单位
const toWei = (number) => {
    return web3.utils.toWei(number.toString(), "ether");
};

// 辅助函数：将 wei 转换为普通单位
const fromWei = (number) => {
    return web3.utils.fromWei(number.toString(), "ether");
};

module.exports = async function(callback) {
    try {
        console.log('开始执行 KWT 转账...');

        // 获取合约实例
        const kerwinToken = await KerwinToken.deployed();
        
        // 转账参数
        const fromAddress = '0xa4AC1352E0ed738d573c645200f5A9F7dFe7B766';
        const toAddress = '0x699562Fceb93017dA8e71cA86f8648E214D407FE';
        const amount = toWei('300000');  // 300000 KWT

        // 转账前检查发送方余额
        const balanceBefore = await kerwinToken.balanceOf(fromAddress);
        console.log('发送方转账前余额：', fromWei(balanceBefore), 'KWT');

        if (balanceBefore < amount) {
            throw new Error('发送方余额不足');
        }

        // 执行转账
        console.log('正在转账...');
        await kerwinToken.transfer(toAddress, amount, {
            from: fromAddress
        });

        // 转账后查询双方余额
        const senderBalance = await kerwinToken.balanceOf(fromAddress);
        const receiverBalance = await kerwinToken.balanceOf(toAddress);

        console.log('转账成功！');
        console.log('发送方当前余额：', fromWei(senderBalance), 'KWT');
        console.log('接收方当前余额：', fromWei(receiverBalance), 'KWT');

    } catch (error) {
        console.error('转账失败：', error.message);
    }
    
    callback();
}
